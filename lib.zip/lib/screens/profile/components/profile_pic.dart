import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import '../../../screens/profile/components/add_avatar_page.dart';

class ProfilePic extends StatefulWidget {
  final String? initialAvatarSvgData;
  final String? initialName;

  const ProfilePic({Key? key, this.initialAvatarSvgData, this.initialName}) : super(key: key);

  @override
  _ProfilePicState createState() => _ProfilePicState();
}

class _ProfilePicState extends State<ProfilePic> {
  String? _avatarSvgData;
  String? _name;

  @override
  void initState() {
    super.initState();
    _avatarSvgData = widget.initialAvatarSvgData;
    _name = widget.initialName;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(
          height: 115,
          width: 115,
          child: Stack(
            fit: StackFit.expand,
            clipBehavior: Clip.none,
            children: [
              CircleAvatar(
                // Display background image if _avatarSvgData is null
                backgroundImage: _avatarSvgData == null
                    ? AssetImage("assets/images/Profile Image.png") as ImageProvider
                    : null,
                child: _avatarSvgData != null
                    ? _buildAvatarImage(context)
                    : null,
              ),
              Positioned(
                right: -16,
                bottom: 0,
                child: SizedBox(
                  height: 46,
                  width: 46,
                  child: TextButton(
                    style: TextButton.styleFrom(
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(50),
                        side: BorderSide(color: Colors.white),
                      ),
                      backgroundColor: Color(0xFF60C6A2),
                    ),
                    onPressed: () async {
                      final result = await Navigator.pushNamed(
                        context,
                        AddAvatarPage.routeName,
                      );
                      if (result != null && result is Map<String, String>) {
                        setState(() {
                          _avatarSvgData = result['avatarSvgData'];
                          _name = result['name'];
                        });
                      }
                    },
                    child: SvgPicture.asset("assets/icons/Camera Icon.svg"),
                  ),
                ),
              ),
            ],
          ),
        ),
        if (_name != null)
          Padding(
            padding: const EdgeInsets.only(top: 8.0),
            child: Text(
              'Hi, $_name!',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
      ],
    );
  }

  Widget _buildAvatarImage(BuildContext context) {
  if (_avatarSvgData != null) {
    return SvgPicture.string(
      _avatarSvgData!,
      fit: BoxFit.contain,
      placeholderBuilder: (context) => Center(
        child: CircularProgressIndicator(),
      ),
      // Handle errors gracefully (optional)
      // onError: (error, stackTrace) {
      //   print('Error loading SVG: $error');
      //   return Icon(Icons.error); // Placeholder for error case
      // },
    );
  }

  // Placeholder widget if no avatar data is available
  return CircleAvatar(
    child: Icon(Icons.person),
  );
}

}
